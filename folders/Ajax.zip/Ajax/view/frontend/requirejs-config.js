var config = {
    map: {
        '*': {
            ajax: 'Vendor_Ajax/js/ajax',
        }
    }
};
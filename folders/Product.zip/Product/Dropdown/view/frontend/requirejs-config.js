var config = {
    map: {
        '*': {
            'Magento_ConfigurableProduct/js/configurable':'Product_Dropdown/js/configurable'
        }
    }
};